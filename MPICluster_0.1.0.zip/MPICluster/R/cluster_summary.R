#' Summarize original feature values by cluster
#'
#' @param data Original data.frame or matrix.
#' @param clusters Integer/factor cluster assignments with one value per row.
#' @param feature_cols Numeric columns to summarize. Defaults to numeric columns.
#' @param fun Summary function, default `mean`.
#' @param na.rm Passed to `fun` when supported.
#' @return data.frame with one row per cluster.
#' @export
cluster_summary <- function(data,
                            clusters,
                            feature_cols = NULL,
                            fun = mean,
                            na.rm = TRUE) {
  dat <- as.data.frame(data, check.names = FALSE)
  if (length(clusters) != nrow(dat)) stop("`clusters` length must equal nrow(data).", call. = FALSE)
  if (is.null(feature_cols)) feature_cols <- names(dat)[vapply(dat, is.numeric, logical(1))]
  if (!length(feature_cols)) stop("No numeric feature columns selected.", call. = FALSE)

  tmp <- dat[, feature_cols, drop = FALSE]
  tmp$.cluster <- clusters
  split_dat <- split(tmp[, feature_cols, drop = FALSE], tmp$.cluster)
  rows <- lapply(names(split_dat), function(g) {
    x <- split_dat[[g]]
    vals <- vapply(x, function(z) {
      tryCatch(fun(z, na.rm = na.rm), error = function(e) fun(z))
    }, numeric(1))
    c(cluster = g, n = nrow(x), vals)
  })
  out <- as.data.frame(do.call(rbind, rows), stringsAsFactors = FALSE, check.names = FALSE)
  for (nm in setdiff(names(out), "cluster")) out[[nm]] <- as.numeric(out[[nm]])
  out
}
