#' Scan candidate cluster numbers using average silhouette width
#'
#' Silhouette width is defined only for two or more clusters; therefore k = 1
#' is not evaluated.
#'
#' @param x Prepared features, data.frame, or numeric matrix.
#' @param k_range Integer vector of candidate cluster counts, default 2:10.
#' @param distance Distance metric for `stats::dist`.
#' @param method Linkage method for `stats::hclust`.
#' @return data.frame with `k` and `average_silhouette`.
#' @export
silhouette_scan <- function(x,
                            k_range = 2:10,
                            distance = "euclidean",
                            method = "ward.D2") {
  mat <- .extract_matrix(x)
  k_range <- sort(unique(as.integer(k_range)))
  k_range <- k_range[is.finite(k_range) & k_range >= 2L & k_range < nrow(mat)]
  if (!length(k_range)) stop("No valid k values remain after filtering.", call. = FALSE)

  if (method %in% c("ward.D", "ward.D2") && distance != "euclidean") {
    warning("Ward linkage is ordinarily paired with Euclidean distance.", call. = FALSE)
  }

  d <- stats::dist(mat, method = distance)
  hc <- stats::hclust(d, method = method)
  vals <- vapply(k_range, function(k) {
    g <- stats::cutree(hc, k = k)
    mean(cluster::silhouette(g, d)[, "sil_width"])
  }, numeric(1))

  data.frame(k = k_range, average_silhouette = vals)
}
