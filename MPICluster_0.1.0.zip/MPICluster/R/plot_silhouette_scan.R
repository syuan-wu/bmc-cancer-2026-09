#' Plot a silhouette scan
#'
#' @param scan A data.frame returned by `silhouette_scan`.
#' @param selected_k Optional selected k to mark with a vertical dashed line.
#' @param ... Additional arguments passed to `plot`.
#' @return Invisibly returns `scan`.
#' @export
plot_silhouette_scan <- function(scan, selected_k = NULL, ...) {
  if (!all(c("k", "average_silhouette") %in% names(scan))) {
    stop("`scan` must contain columns `k` and `average_silhouette`.", call. = FALSE)
  }
  graphics::plot(scan$k, scan$average_silhouette, type = "b",
                 xlab = "Number of clusters (k)",
                 ylab = "Average silhouette width", ...)
  if (!is.null(selected_k)) graphics::abline(v = selected_k, lty = 2)
  invisible(scan)
}
