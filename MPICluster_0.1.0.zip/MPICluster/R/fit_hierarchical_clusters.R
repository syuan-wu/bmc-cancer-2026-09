#' Fit hierarchical clusters
#'
#' @param x Prepared features, data.frame, or numeric matrix.
#' @param k Number of clusters.
#' @param distance Distance metric passed to `stats::dist`.
#' @param method Linkage method passed to `stats::hclust`.
#' @return An object of class `mpi_cluster_fit` containing the dendrogram,
#'   cluster assignments, and analysis settings.
#' @export
fit_hierarchical_clusters <- function(x,
                                      k = 3L,
                                      distance = "euclidean",
                                      method = "ward.D2") {
  mat <- .extract_matrix(x)
  if (nrow(mat) < 2L) stop("At least two rows are required.", call. = FALSE)
  k <- as.integer(k)
  if (length(k) != 1L || is.na(k) || k < 2L || k >= nrow(mat)) {
    stop("`k` must be an integer between 2 and nrow(x) - 1.", call. = FALSE)
  }
  if (method %in% c("ward.D", "ward.D2") && distance != "euclidean") {
    warning("Ward linkage is ordinarily paired with Euclidean distance.", call. = FALSE)
  }

  d <- stats::dist(mat, method = distance)
  hc <- stats::hclust(d, method = method)
  groups <- stats::cutree(hc, k = k)

  out <- list(
    hclust = hc,
    clusters = groups,
    k = k,
    distance = distance,
    method = method,
    matrix = mat,
    dist = d
  )
  class(out) <- "mpi_cluster_fit"
  out
}

#' @export
print.mpi_cluster_fit <- function(x, ...) {
  cat("Hierarchical clustering fit\n")
  cat("  rows:", nrow(x$matrix), "\n")
  cat("  features:", ncol(x$matrix), "\n")
  cat("  k:", x$k, "\n")
  cat("  distance:", x$distance, "\n")
  cat("  linkage:", x$method, "\n")
  invisible(x)
}
