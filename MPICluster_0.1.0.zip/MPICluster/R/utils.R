.assert_data_frame <- function(data) {
  if (!is.data.frame(data) && !is.matrix(data)) {
    stop("`data` must be a data.frame or matrix.", call. = FALSE)
  }
}

.as_numeric_matrix <- function(x) {
  x <- as.data.frame(x, check.names = FALSE)
  ok <- vapply(x, is.numeric, logical(1))
  if (!all(ok)) {
    bad <- names(x)[!ok]
    stop("All selected clustering features must be numeric. Non-numeric columns: ",
         paste(bad, collapse = ", "), call. = FALSE)
  }
  as.matrix(x)
}

.extract_matrix <- function(x) {
  if (inherits(x, "mpi_prepared_features")) return(x$matrix)
  if (is.data.frame(x) || is.matrix(x)) return(.as_numeric_matrix(x))
  stop("`x` must be a prepared feature object, data.frame, or matrix.", call. = FALSE)
}
