#' Prepare heterogeneous features for clustering
#'
#' Selects numeric feature columns, optionally converts specified P-value columns
#' to binary indicators, handles non-finite/missing values, and optionally
#' standardizes each feature to mean 0 and standard deviation 1.
#'
#' @param data A data.frame or matrix with rows representing objects to cluster.
#' @param feature_cols Character vector of columns to use. Defaults to all columns.
#' @param binary_threshold_cols Optional character vector of columns containing
#'   P-values to convert to 1 when P < `threshold` and 0 otherwise.
#' @param threshold Numeric threshold used for binary conversion. Default 0.05.
#' @param transformations Optional named list of functions. Each function is
#'   applied to the corresponding column before binary conversion and scaling.
#' @param na_action Either "omit" or "fail".
#' @param standardize Logical; if TRUE, use base R `scale()`.
#' @return An object of class `mpi_prepared_features`.
#' @export
prepare_cluster_features <- function(data,
                                     feature_cols = NULL,
                                     binary_threshold_cols = NULL,
                                     threshold = 0.05,
                                     transformations = NULL,
                                     na_action = c("omit", "fail"),
                                     standardize = TRUE) {
  .assert_data_frame(data)
  na_action <- match.arg(na_action)
  dat <- as.data.frame(data, check.names = FALSE)

  if (is.null(feature_cols)) feature_cols <- names(dat)
  missing_cols <- setdiff(feature_cols, names(dat))
  if (length(missing_cols)) {
    stop("Unknown feature columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  }
  dat <- dat[, feature_cols, drop = FALSE]

  if (!is.null(transformations)) {
    if (is.null(names(transformations)) || any(names(transformations) == "")) {
      stop("`transformations` must be a named list of functions.", call. = FALSE)
    }
    bad <- setdiff(names(transformations), names(dat))
    if (length(bad)) stop("Unknown transformation columns: ", paste(bad, collapse = ", "), call. = FALSE)
    for (nm in names(transformations)) {
      fun <- transformations[[nm]]
      if (!is.function(fun)) stop("Transformation for `", nm, "` is not a function.", call. = FALSE)
      dat[[nm]] <- fun(dat[[nm]])
    }
  }

  if (!is.null(binary_threshold_cols)) {
    bad <- setdiff(binary_threshold_cols, names(dat))
    if (length(bad)) stop("Unknown binary-threshold columns: ", paste(bad, collapse = ", "), call. = FALSE)
    for (nm in binary_threshold_cols) {
      if (!is.numeric(dat[[nm]])) stop("Binary-threshold column `", nm, "` must be numeric.", call. = FALSE)
      dat[[nm]] <- ifelse(is.na(dat[[nm]]), NA_real_, as.numeric(dat[[nm]] < threshold))
    }
  }

  mat <- .as_numeric_matrix(dat)
  mat[!is.finite(mat)] <- NA_real_
  complete <- stats::complete.cases(mat)

  if (na_action == "fail" && any(!complete)) {
    stop(sum(!complete), " row(s) contain missing or non-finite values.", call. = FALSE)
  }

  dropped <- which(!complete)
  if (na_action == "omit") mat <- mat[complete, , drop = FALSE]
  if (nrow(mat) < 2L) stop("Fewer than two complete rows remain after preprocessing.", call. = FALSE)

  center <- scale <- NULL
  if (standardize) {
    scaled <- base::scale(mat)
    center <- attr(scaled, "scaled:center")
    scale <- attr(scaled, "scaled:scale")
    if (any(!is.finite(scaled))) {
      stop("Standardization produced non-finite values. Check for zero-variance features.", call. = FALSE)
    }
    mat <- scaled
  }

  out <- list(
    matrix = mat,
    retained_rows = which(complete),
    dropped_rows = dropped,
    feature_cols = feature_cols,
    binary_threshold_cols = binary_threshold_cols,
    threshold = threshold,
    standardize = standardize,
    center = center,
    scale = scale,
    transformations = names(transformations)
  )
  class(out) <- "mpi_prepared_features"
  out
}
