# MPICluster

`MPICluster` is a small, dataset-agnostic R package for the clustering stage of a multi-parameter gene-screening workflow.

It intentionally does **not** contain TCGA/KIRC-specific file paths, gene names, cohort labels, or hard-coded column positions.

## Main functions

- `prepare_cluster_features()` — optional binary conversion of thresholded P-value features, missing/non-finite handling, and `scale()` standardization.
- `silhouette_scan()` — average silhouette width for candidate `k >= 2`.
- `fit_hierarchical_clusters()` — Euclidean/Ward.D2 hierarchical clustering by default.
- `cluster_summary()` — summarize original feature values by cluster.

## Example

```r
library(MPICluster)

set.seed(1)
feature_table <- data.frame(
  tumor_fc = rexp(300, 1),
  metastasis_fc = rlnorm(300, 0, 0.2),
  stage_p = runif(300),
  stage_cor = runif(300, -1, 1),
  survival_p = runif(300),
  hazard_ratio = rlnorm(300, 0, 0.3)
)

prep <- prepare_cluster_features(
  feature_table,
  binary_threshold_cols = c("stage_p", "survival_p"),
  threshold = 0.05,
  standardize = TRUE
)

scan <- silhouette_scan(prep, k_range = 2:10)
plot_silhouette_scan(scan, selected_k = 3)
fit <- fit_hierarchical_clusters(prep, k = 3)
fit
```

## Reproducibility note

The package exposes each preprocessing choice explicitly. If binary P-value indicators are used, the threshold is recorded in the returned object. Users should justify those choices scientifically; the package does not treat a nominal P-value threshold as independent inferential evidence.
