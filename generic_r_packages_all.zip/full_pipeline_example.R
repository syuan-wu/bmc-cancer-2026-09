# Example showing how the three independent packages can be chained.
# The simulated data are intentionally unrelated to any specific cancer dataset.

library(MPICluster)
library(IterGeneSelect)
library(SignatureModel)

set.seed(42)

# ---- 1) Multi-parameter clustering of candidate features ----
p <- 80
feature_table <- data.frame(
  tumor_fc = rlnorm(p, 0.5, 0.5),
  metastasis_fc = rlnorm(p, 0, 0.3),
  stage_p = runif(p),
  stage_cor = runif(p, -1, 1),
  survival_p = runif(p),
  hazard_ratio = rlnorm(p, 0, 0.4)
)
rownames(feature_table) <- paste0("G", seq_len(p))

prep <- prepare_cluster_features(
  feature_table,
  binary_threshold_cols = c("stage_p", "survival_p"),
  threshold = 0.05,
  standardize = TRUE
)
scan <- silhouette_scan(prep, 2:8)
cluster_fit <- fit_hierarchical_clusters(prep, k = 3)

# In a real study, biological/pathway criteria can be used after clustering to
# define an upstream candidate gene pool. Here we use all simulated genes.
candidate_genes <- rownames(feature_table)

# ---- 2) Iterative gene sampling in sample-by-gene data ----
n <- 220
expr <- as.data.frame(matrix(rnorm(n * p), nrow = n))
names(expr) <- candidate_genes
expr$response <- rbinom(
  n, 1,
  plogis(0.9 * expr$G2 - 0.7 * expr$G11 + 0.6 * expr$G25)
)

# Optional upstream stepwise reduction
sw <- stepwise_logistic_select(
  expr,
  response = "response",
  candidates = candidate_genes,
  trace = 0
)
reduced_pool <- sw$selected_genes

# For a quick example ensure at least 20 predictors are available.
if (length(reduced_pool) < 20) reduced_pool <- candidate_genes[1:40]

sampling <- iterative_gene_sampling(
  expr,
  response = "response",
  predictors = reduced_pool,
  subset_size = 20,
  n_iter = 1000,      # use 10000 for the finalized study workflow
  seed = 20260903,
  progress = FALSE
)

top20 <- selection_frequency(
  sampling,
  filter = "above_mean",
  top_n = min(20, length(unique(reduced_pool)))
)$gene

# ---- 3) Final combination search and model construction ----
# Searching all non-empty subsets of 20 genes evaluates 1,048,575 models.
print(count_model_space(length(top20), seq_along(top20)))

combo <- search_gene_combinations(
  expr,
  response = "response",
  candidates = top20,
  sizes = seq_along(top20),
  keep = "best_per_size",
  progress = FALSE
)

final_genes <- strsplit(combo$global_best$genes, ";", fixed = TRUE)[[1]]
final_model <- fit_gene_signature(
  expr,
  response = "response",
  genes = final_genes,
  preprocessing_note = "Apply the same expression preprocessing used in model development."
)

print(model_specification(final_model))
print(single_gene_deletion(expr, "response", final_genes))
