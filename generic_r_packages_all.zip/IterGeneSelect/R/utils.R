.quote_name <- function(x) {
  paste0("`", gsub("`", "", x, fixed = TRUE), "`")
}

.make_formula <- function(response, predictors) {
  rhs <- paste(.quote_name(predictors), collapse = " + ")
  stats::as.formula(paste(.quote_name(response), "~", rhs))
}

.binary_info <- function(y, positive = NULL) {
  keep <- !is.na(y)
  vals <- unique(y[keep])
  if (length(vals) != 2L) stop("Response must contain exactly two non-missing classes.", call. = FALSE)

  if (is.factor(y)) vals <- levels(droplevels(y[keep]))
  if (is.null(positive)) {
    if (all(sort(as.character(vals)) %in% c("0", "1"))) {
      positive <- vals[match("1", as.character(vals))]
    } else {
      positive <- vals[length(vals)]
    }
  }
  if (!positive %in% vals) stop("`positive` is not a response class.", call. = FALSE)
  negative <- vals[vals != positive][1]
  y01 <- ifelse(is.na(y), NA_integer_, as.integer(y == positive))
  list(y = y01, positive = positive, negative = negative)
}

.prepare_model_data <- function(data, response, predictors, positive = NULL, mode = "modelwise") {
  missing_cols <- setdiff(c(response, predictors), names(data))
  if (length(missing_cols)) stop("Missing columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  dat <- as.data.frame(data, check.names = FALSE)
  bi <- .binary_info(dat[[response]], positive)
  dat[[response]] <- bi$y
  if (mode == "global") {
    dat <- dat[stats::complete.cases(dat[, c(response, predictors), drop = FALSE]), , drop = FALSE]
  }
  list(data = dat, positive = bi$positive, negative = bi$negative)
}
