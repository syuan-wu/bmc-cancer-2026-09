#' Summarize iterative-sampling performance
#'
#' @param results Output from `iterative_gene_sampling`.
#' @return One-row data.frame with AUC summary statistics and convergence count.
#' @export
sampling_summary <- function(results) {
  if (!"auc" %in% names(results)) stop("Invalid sampling result.", call. = FALSE)
  a <- results$auc[is.finite(results$auc)]
  if (!length(a)) stop("No finite AUC values are available.", call. = FALSE)
  data.frame(
    iterations = nrow(results),
    finite_auc = length(a),
    converged = sum(results$converged, na.rm = TRUE),
    mean_auc = mean(a),
    sd_auc = stats::sd(a),
    median_auc = stats::median(a),
    q025 = stats::quantile(a, 0.025, names = FALSE),
    q975 = stats::quantile(a, 0.975, names = FALSE),
    min_auc = min(a),
    max_auc = max(a)
  )
}
