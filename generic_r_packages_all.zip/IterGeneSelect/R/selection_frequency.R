#' Count gene selection frequency among sampled combinations
#'
#' @param results Output from `iterative_gene_sampling`.
#' @param filter One of "above_mean", "all", or "threshold".
#' @param threshold Numeric AUC threshold when `filter = "threshold"`.
#' @param top_n Optional number of top genes to return.
#' @return data.frame with gene, frequency, and proportion of retained iterations.
#' @export
selection_frequency <- function(results,
                                filter = c("above_mean", "all", "threshold"),
                                threshold = NULL,
                                top_n = NULL) {
  filter <- match.arg(filter)
  if (!all(c("auc", "genes") %in% names(results))) stop("Invalid sampling result.", call. = FALSE)
  valid <- is.finite(results$auc)
  dat <- results[valid, , drop = FALSE]
  if (!nrow(dat)) stop("No finite AUC values are available.", call. = FALSE)

  if (filter == "above_mean") dat <- dat[dat$auc > mean(dat$auc), , drop = FALSE]
  if (filter == "threshold") {
    if (is.null(threshold) || length(threshold) != 1L || !is.finite(threshold)) {
      stop("Provide a finite numeric `threshold`.", call. = FALSE)
    }
    dat <- dat[dat$auc >= threshold, , drop = FALSE]
  }
  if (!nrow(dat)) return(data.frame(gene = character(), frequency = integer(), proportion = numeric()))

  genes <- unlist(strsplit(dat$genes, ";", fixed = TRUE), use.names = FALSE)
  tab <- sort(table(genes), decreasing = TRUE)
  out <- data.frame(
    gene = names(tab),
    frequency = as.integer(tab),
    proportion = as.integer(tab) / nrow(dat),
    stringsAsFactors = FALSE
  )
  if (!is.null(top_n)) out <- utils::head(out, as.integer(top_n))
  attr(out, "retained_iterations") <- nrow(dat)
  out
}
