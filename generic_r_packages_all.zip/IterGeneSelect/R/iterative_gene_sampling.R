#' Iteratively sample unique gene subsets and evaluate logistic models
#'
#' In every iteration, `subset_size` unique predictors are sampled without
#' replacement. The full predictor pool is available again in the next iteration.
#'
#' @param data Development data.frame; rows are samples and predictor columns are genes/features.
#' @param response Name of the binary response column.
#' @param predictors Candidate predictor names. Defaults to all columns except `response`.
#' @param subset_size Number of unique predictors sampled in each iteration.
#' @param n_iter Number of iterations; default 10000.
#' @param seed Optional integer seed for reproducible reruns.
#' @param positive Optional positive-class label.
#' @param evaluation_data Optional independent/held-out data.frame. If NULL, AUC is
#'   calculated in the development data and should not be interpreted as independent validation.
#' @param na_action Either "modelwise" (glm handles missing values per subset) or
#'   "global" (complete cases across all candidate predictors before sampling).
#' @param progress Logical; print progress every approximately 10 percent of iterations.
#' @return data.frame with iteration number, AUC, number of training/evaluation samples,
#'   convergence status, and a semicolon-separated gene list.
#' @export
iterative_gene_sampling <- function(data,
                                    response,
                                    predictors = NULL,
                                    subset_size = 20L,
                                    n_iter = 10000L,
                                    seed = NULL,
                                    positive = NULL,
                                    evaluation_data = NULL,
                                    na_action = c("modelwise", "global"),
                                    progress = interactive()) {
  if (!is.data.frame(data)) data <- as.data.frame(data, check.names = FALSE)
  if (!response %in% names(data)) stop("Response column not found: ", response, call. = FALSE)
  if (is.null(predictors)) predictors <- setdiff(names(data), response)
  predictors <- unique(as.character(predictors))
  if (!length(predictors)) stop("No predictors supplied.", call. = FALSE)
  if (any(!predictors %in% names(data))) stop("Some predictors are absent from `data`.", call. = FALSE)

  subset_size <- as.integer(subset_size)
  n_iter <- as.integer(n_iter)
  if (subset_size < 1L || subset_size > length(predictors)) {
    stop("`subset_size` must be between 1 and the number of candidate predictors.", call. = FALSE)
  }
  if (n_iter < 1L) stop("`n_iter` must be at least 1.", call. = FALSE)
  if (!is.null(seed)) set.seed(seed)
  na_action <- match.arg(na_action)

  prep <- .prepare_model_data(data, response, predictors, positive, mode = na_action)
  train <- prep$data

  eval <- NULL
  if (!is.null(evaluation_data)) {
    eval <- as.data.frame(evaluation_data, check.names = FALSE)
    missing_eval <- setdiff(c(response, predictors), names(eval))
    if (length(missing_eval)) stop("Evaluation data are missing: ", paste(missing_eval, collapse = ", "), call. = FALSE)
    eval_bi <- .binary_info(eval[[response]], prep$positive)
    eval[[response]] <- eval_bi$y
  }

  out_iter <- integer(n_iter)
  out_auc <- rep(NA_real_, n_iter)
  out_ntrain <- integer(n_iter)
  out_neval <- integer(n_iter)
  out_conv <- logical(n_iter)
  out_genes <- character(n_iter)
  checkpoints <- unique(round(seq(1, n_iter, length.out = 11)))

  for (i in seq_len(n_iter)) {
    genes <- sample(predictors, size = subset_size, replace = FALSE)
    f <- .make_formula(response, genes)
    fit <- try(stats::glm(f, data = train, family = stats::binomial(), na.action = stats::na.exclude), silent = TRUE)

    out_iter[i] <- i
    out_genes[i] <- paste(genes, collapse = ";")

    if (inherits(fit, "try-error")) {
      out_conv[i] <- FALSE
      next
    }
    out_conv[i] <- isTRUE(fit$converged)
    out_ntrain[i] <- stats::nobs(fit)

    target <- if (is.null(eval)) train else eval
    pred <- try(stats::predict(fit, newdata = target, type = "response"), silent = TRUE)
    if (inherits(pred, "try-error")) next

    y <- target[[response]]
    keep <- stats::complete.cases(y, pred)
    out_neval[i] <- sum(keep)
    out_auc[i] <- auc_binary(y[keep], pred[keep], positive = 1L)

    if (isTRUE(progress) && i %in% checkpoints) message("Completed ", i, "/", n_iter, " iterations")
  }

  out <- data.frame(
    iteration = out_iter,
    auc = out_auc,
    n_train = out_ntrain,
    n_eval = out_neval,
    converged = out_conv,
    genes = out_genes,
    stringsAsFactors = FALSE
  )
  attr(out, "settings") <- list(
    response = response,
    predictors = predictors,
    subset_size = subset_size,
    n_iter = n_iter,
    seed = seed,
    positive = prep$positive,
    negative = prep$negative,
    evaluation = if (is.null(eval)) "development" else "external_or_heldout",
    na_action = na_action
  )
  out
}
