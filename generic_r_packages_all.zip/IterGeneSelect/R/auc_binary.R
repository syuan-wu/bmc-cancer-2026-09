#' Calculate ROC AUC for a binary outcome
#'
#' @param y Binary response coded as 0/1 or a two-class vector.
#' @param score Numeric prediction score; larger values should indicate the positive class.
#' @param positive Optional positive-class label.
#' @return Numeric AUC.
#' @export
auc_binary <- function(y, score, positive = NULL) {
  bi <- .binary_info(y, positive)
  y01 <- bi$y
  keep <- stats::complete.cases(y01, score)
  y01 <- y01[keep]
  score <- score[keep]
  n1 <- sum(y01 == 1L)
  n0 <- sum(y01 == 0L)
  if (n1 == 0L || n0 == 0L) return(NA_real_)
  r <- rank(score, ties.method = "average")
  (sum(r[y01 == 1L]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
