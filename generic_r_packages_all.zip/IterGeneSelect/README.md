# IterGeneSelect

`IterGeneSelect` implements dataset-agnostic iterative gene-subset sampling for binary logistic-regression models.

The key sampling rule is explicit: **predictors are sampled without replacement within an iteration, and the complete predictor pool is restored before the next iteration**.

## Main functions

- `iterative_gene_sampling()` — repeated random subset selection and AUC calculation.
- `selection_frequency()` — ranks genes by occurrence among retained higher-performing combinations.
- `sampling_summary()` — summarizes the AUC distribution.
- `auc_binary()` — dependency-light AUC calculation.

## Example

```r
library(IterGeneSelect)

set.seed(123)
n <- 180
p <- 60
x <- as.data.frame(matrix(rnorm(n * p), nrow = n))
names(x) <- paste0("G", seq_len(p))
x$response <- rbinom(n, 1, plogis(0.8*x$G2 - 0.6*x$G9 + 0.5*x$G17))

res <- iterative_gene_sampling(
  data = x,
  response = "response",
  predictors = paste0("G", seq_len(p)),
  subset_size = 20,
  n_iter = 10000,
  seed = 20260903
)

sampling_summary(res)
top20 <- selection_frequency(res, filter = "above_mean", top_n = 20)
```

## Important interpretation

When `evaluation_data = NULL`, the reported AUC is calculated in the same development cohort used to fit each sampled model. This procedure is intended for **gene-combination exploration and selection-frequency assessment**, not independent patient-level validation. A held-out or external dataset can be supplied through `evaluation_data` when appropriate.
