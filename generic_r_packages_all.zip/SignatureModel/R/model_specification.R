#' Extract the complete final model specification
#'
#' @param object A `gene_signature_fit` object.
#' @param digits Number of digits used in the human-readable equation.
#' @return A list with coefficient table, intercept, gene list, response labels,
#'   preprocessing note, linear-predictor equation, and probability equation.
#' @export
model_specification <- function(object, digits = 6L) {
  if (!inherits(object, "gene_signature_fit")) stop("`object` must be a gene_signature_fit.", call. = FALSE)
  co <- stats::coef(object$model)
  intercept <- unname(co["(Intercept)"])
  beta <- co[names(co) != "(Intercept)"]
  tab <- data.frame(
    term = names(beta),
    coefficient = unname(beta),
    stringsAsFactors = FALSE
  )

  fmt <- function(z) format(round(z, digits), nsmall = digits, scientific = FALSE, trim = TRUE)
  pieces <- vapply(seq_along(beta), function(i) {
    b <- beta[i]
    sign <- if (b >= 0) " + " else " - "
    paste0(sign, fmt(abs(b)), "*", .quote_name(names(beta)[i]))
  }, character(1))
  linear <- paste0("eta = ", fmt(intercept), paste(pieces, collapse = ""))
  prob <- "P(positive) = 1 / (1 + exp(-eta))"

  list(
    genes = object$genes,
    intercept = intercept,
    coefficients = tab,
    response = object$response,
    positive = object$positive,
    negative = object$negative,
    preprocessing_note = object$preprocessing_note,
    linear_predictor_equation = linear,
    probability_equation = prob
  )
}
