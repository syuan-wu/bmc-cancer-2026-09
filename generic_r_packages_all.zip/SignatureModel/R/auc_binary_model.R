#' Calculate AUC for a binary response and score
#'
#' @param y Binary response.
#' @param score Numeric prediction score.
#' @param positive Optional positive-class label.
#' @return Numeric ROC AUC.
#' @export
auc_binary_model <- function(y, score, positive = NULL) {
  bi <- .binary_info(y, positive)
  .auc01(bi$y, score)
}
