#' Fit a final multigene logistic signature
#'
#' @param data Development data.frame.
#' @param response Binary response column name.
#' @param genes Final predictor names.
#' @param positive Optional positive-class label.
#' @param preprocessing_note Optional text describing the expression/preprocessing
#'   scale required for new samples.
#' @return Object of class `gene_signature_fit`.
#' @export
fit_gene_signature <- function(data,
                               response,
                               genes,
                               positive = NULL,
                               preprocessing_note = NULL) {
  prep <- .prep_binary_data(data, response, positive)
  dat <- prep$data
  genes <- unique(as.character(genes))
  missing_cols <- setdiff(genes, names(dat))
  if (length(missing_cols)) stop("Missing gene columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  if (!length(genes)) stop("No genes supplied.", call. = FALSE)

  fit <- .fit_glm(dat, response, genes)
  out <- list(
    model = fit,
    response = response,
    genes = genes,
    positive = prep$positive,
    negative = prep$negative,
    preprocessing_note = preprocessing_note
  )
  class(out) <- "gene_signature_fit"
  out
}

#' @export
print.gene_signature_fit <- function(x, ...) {
  cat("Gene signature logistic model\n")
  cat("  genes:", length(x$genes), "\n")
  cat("  response:", x$response, "\n")
  cat("  positive class:", as.character(x$positive), "\n")
  cat("  converged:", isTRUE(x$model$converged), "\n")
  invisible(x)
}
