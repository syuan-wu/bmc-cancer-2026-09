.quote_name <- function(x) paste0("`", gsub("`", "", x, fixed = TRUE), "`")

.make_formula <- function(response, predictors) {
  if (!length(predictors)) return(stats::as.formula(paste(.quote_name(response), "~ 1")))
  stats::as.formula(paste(.quote_name(response), "~", paste(.quote_name(predictors), collapse = " + ")))
}

.binary_info <- function(y, positive = NULL) {
  keep <- !is.na(y)
  vals <- unique(y[keep])
  if (length(vals) != 2L) stop("Response must contain exactly two non-missing classes.", call. = FALSE)
  if (is.factor(y)) vals <- levels(droplevels(y[keep]))
  if (is.null(positive)) {
    if (all(sort(as.character(vals)) %in% c("0", "1"))) positive <- vals[match("1", as.character(vals))]
    else positive <- vals[length(vals)]
  }
  if (!positive %in% vals) stop("`positive` is not a response class.", call. = FALSE)
  negative <- vals[vals != positive][1]
  y01 <- ifelse(is.na(y), NA_integer_, as.integer(y == positive))
  list(y = y01, positive = positive, negative = negative)
}

.prep_binary_data <- function(data, response, positive = NULL) {
  dat <- as.data.frame(data, check.names = FALSE)
  if (!response %in% names(dat)) stop("Response column not found: ", response, call. = FALSE)
  bi <- .binary_info(dat[[response]], positive)
  dat[[response]] <- bi$y
  list(data = dat, positive = bi$positive, negative = bi$negative)
}

.fit_glm <- function(data, response, genes) {
  stats::glm(.make_formula(response, genes), data = data,
             family = stats::binomial(), na.action = stats::na.exclude)
}

.auc01 <- function(y01, score) {
  keep <- stats::complete.cases(y01, score)
  y <- y01[keep]
  s <- score[keep]
  n1 <- sum(y == 1L)
  n0 <- sum(y == 0L)
  if (n1 == 0L || n0 == 0L) return(NA_real_)
  r <- rank(s, ties.method = "average")
  (sum(r[y == 1L]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

.eval_fit <- function(fit, target, response) {
  p <- stats::predict(fit, newdata = target, type = "response")
  y <- target[[response]]
  list(auc = .auc01(y, p), n = sum(stats::complete.cases(y, p)), probability = p)
}
