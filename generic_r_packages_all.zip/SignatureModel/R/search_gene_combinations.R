#' Exhaustively evaluate predictor combinations by logistic-regression AUC
#'
#' @param data Development data.frame.
#' @param response Binary response column name.
#' @param candidates Candidate predictor names.
#' @param sizes Model sizes to evaluate; defaults to all sizes 1:p.
#' @param positive Optional positive-class label.
#' @param evaluation_data Optional held-out/external data. If NULL, AUC is apparent
#'   development-set performance.
#' @param keep Either "best_per_size" or "all".
#' @param max_combinations Safety cap on the total number of models to fit.
#' @param progress Logical; report completion by model size.
#' @return A list containing per-size best models, global best, and optionally all results.
#' @export
search_gene_combinations <- function(data,
                                     response,
                                     candidates,
                                     sizes = NULL,
                                     positive = NULL,
                                     evaluation_data = NULL,
                                     keep = c("best_per_size", "all"),
                                     max_combinations = 2000000,
                                     progress = interactive()) {
  keep <- match.arg(keep)
  prep <- .prep_binary_data(data, response, positive)
  train <- prep$data
  candidates <- unique(as.character(candidates))
  missing_cols <- setdiff(candidates, names(train))
  if (length(missing_cols)) stop("Missing candidate columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  p <- length(candidates)
  if (!p) stop("No candidate predictors supplied.", call. = FALSE)

  # Compare every candidate model on the same development samples.
  train <- train[stats::complete.cases(train[, c(response, candidates), drop = FALSE]), , drop = FALSE]
  if (nrow(train) < 3L) stop("Too few complete development samples remain.", call. = FALSE)

  if (is.null(sizes)) sizes <- seq_len(p)
  space <- count_model_space(p, sizes)
  total <- sum(space$combinations)
  if (total > max_combinations) {
    stop("Requested search contains ", format(total, scientific = FALSE),
         " models, exceeding `max_combinations` = ", format(max_combinations, scientific = FALSE),
         ". Increase the cap explicitly if this is intended.", call. = FALSE)
  }

  eval <- NULL
  if (!is.null(evaluation_data)) {
    eval <- as.data.frame(evaluation_data, check.names = FALSE)
    missing_eval <- setdiff(c(response, candidates), names(eval))
    if (length(missing_eval)) stop("Evaluation data are missing: ", paste(missing_eval, collapse = ", "), call. = FALSE)
    eval_bi <- .binary_info(eval[[response]], prep$positive)
    eval[[response]] <- eval_bi$y
    eval <- eval[stats::complete.cases(eval[, c(response, candidates), drop = FALSE]), , drop = FALSE]
    if (nrow(eval) < 2L) stop("Too few complete evaluation samples remain.", call. = FALSE)
  }
  target <- if (is.null(eval)) train else eval

  best_rows <- vector("list", nrow(space))
  all_rows <- if (keep == "all") vector("list", nrow(space)) else NULL

  for (sidx in seq_len(nrow(space))) {
    k <- space$size[sidx]
    cmb <- utils::combn(candidates, k)
    ncomb <- ncol(cmb)
    aucs <- rep(NA_real_, ncomb)
    n_eval <- integer(ncomb)
    conv <- logical(ncomb)

    for (j in seq_len(ncomb)) {
      genes <- cmb[, j]
      fit <- try(.fit_glm(train, response, genes), silent = TRUE)
      if (inherits(fit, "try-error")) next
      conv[j] <- isTRUE(fit$converged)
      ev <- try(.eval_fit(fit, target, response), silent = TRUE)
      if (inherits(ev, "try-error")) next
      aucs[j] <- ev$auc
      n_eval[j] <- ev$n
    }

    if (all(!is.finite(aucs))) {
      best_rows[[sidx]] <- data.frame(size = k, auc = NA_real_, n_eval = 0L,
                                      converged = FALSE, genes = NA_character_)
    } else {
      b <- which.max(replace(aucs, !is.finite(aucs), -Inf))
      best_rows[[sidx]] <- data.frame(
        size = k,
        auc = aucs[b],
        n_eval = n_eval[b],
        converged = conv[b],
        genes = paste(cmb[, b], collapse = ";"),
        stringsAsFactors = FALSE
      )
    }

    if (keep == "all") {
      all_rows[[sidx]] <- data.frame(
        size = rep(k, ncomb),
        auc = aucs,
        n_eval = n_eval,
        converged = conv,
        genes = apply(cmb, 2, paste, collapse = ";"),
        stringsAsFactors = FALSE
      )
    }
    if (isTRUE(progress)) message("Completed model size ", k, " (", ncomb, " combinations)")
  }

  best <- do.call(rbind, best_rows)
  rownames(best) <- NULL
  if (all(!is.finite(best$auc))) global <- best[1, , drop = FALSE]
  else global <- best[which.max(replace(best$auc, !is.finite(best$auc), -Inf)), , drop = FALSE]

  out <- list(
    model_space = space,
    total_models = total,
    best_per_size = best,
    global_best = global,
    all_results = if (keep == "all") do.call(rbind, all_rows) else NULL,
    settings = list(
      response = response,
      candidates = candidates,
      positive = prep$positive,
      negative = prep$negative,
      evaluation = if (is.null(eval)) "development" else "external_or_heldout",
      keep = keep
    )
  )
  out
}
