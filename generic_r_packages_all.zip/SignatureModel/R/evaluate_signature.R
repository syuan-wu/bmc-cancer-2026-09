#' Evaluate a frozen signature on labeled data
#'
#' @param object A `gene_signature_fit` object.
#' @param data Labeled data.frame containing the response and all signature genes.
#' @return One-row data.frame with AUC and evaluable sample size.
#' @export
evaluate_signature <- function(object, data) {
  if (!inherits(object, "gene_signature_fit")) stop("`object` must be a gene_signature_fit.", call. = FALSE)
  dat <- as.data.frame(data, check.names = FALSE)
  if (!object$response %in% names(dat)) stop("Response column is absent from evaluation data.", call. = FALSE)
  bi <- .binary_info(dat[[object$response]], object$positive)
  dat[[object$response]] <- bi$y
  p <- predict_gene_signature(object, dat, type = "probability")
  keep <- stats::complete.cases(dat[[object$response]], p)
  data.frame(
    n = sum(keep),
    auc = .auc01(dat[[object$response]][keep], p[keep])
  )
}
