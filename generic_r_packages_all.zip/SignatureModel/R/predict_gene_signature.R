#' Apply a frozen gene-signature model to new samples
#'
#' @param object A `gene_signature_fit` object.
#' @param newdata New data.frame containing all signature genes.
#' @param type Either "probability" or "linear_predictor".
#' @return Numeric prediction vector.
#' @export
predict_gene_signature <- function(object,
                                   newdata,
                                   type = c("probability", "linear_predictor")) {
  if (!inherits(object, "gene_signature_fit")) stop("`object` must be a gene_signature_fit.", call. = FALSE)
  type <- match.arg(type)
  nd <- as.data.frame(newdata, check.names = FALSE)
  missing_cols <- setdiff(object$genes, names(nd))
  if (length(missing_cols)) stop("New data are missing signature genes: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  ptype <- if (type == "probability") "response" else "link"
  stats::predict(object$model, newdata = nd, type = ptype)
}
