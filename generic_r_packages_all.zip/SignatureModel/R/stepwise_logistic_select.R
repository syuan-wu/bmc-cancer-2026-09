#' Stepwise logistic candidate selection
#'
#' @param data Development data.frame.
#' @param response Name of binary response column.
#' @param candidates Candidate predictor names.
#' @param direction Stepwise direction: "both", "backward", or "forward".
#' @param positive Optional positive-class label.
#' @param trace Passed to `stats::step`.
#' @return A list containing the selected genes and fitted model.
#' @export
stepwise_logistic_select <- function(data,
                                     response,
                                     candidates,
                                     direction = c("both", "backward", "forward"),
                                     positive = NULL,
                                     trace = 0) {
  direction <- match.arg(direction)
  prep <- .prep_binary_data(data, response, positive)
  dat <- prep$data
  candidates <- unique(as.character(candidates))
  missing_cols <- setdiff(candidates, names(dat))
  if (length(missing_cols)) stop("Missing candidate columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)
  if (!length(candidates)) stop("No candidate predictors supplied.", call. = FALSE)

  # Use one common sample set so stepwise models are compared on identical rows.
  dat <- dat[stats::complete.cases(dat[, c(response, candidates), drop = FALSE]), , drop = FALSE]
  if (nrow(dat) < 3L) stop("Too few complete samples remain for stepwise selection.", call. = FALSE)

  full <- .fit_glm(dat, response, candidates)
  null <- .fit_glm(dat, response, character())

  if (direction == "backward") {
    selected_fit <- stats::step(full, direction = "backward", trace = trace)
  } else if (direction == "forward") {
    selected_fit <- stats::step(null,
      scope = list(lower = stats::formula(null), upper = stats::formula(full)),
      direction = "forward", trace = trace)
  } else {
    selected_fit <- stats::step(null,
      scope = list(lower = stats::formula(null), upper = stats::formula(full)),
      direction = "both", trace = trace)
  }

  selected <- setdiff(names(stats::coef(selected_fit)), "(Intercept)")
  list(
    selected_genes = selected,
    model = selected_fit,
    positive = prep$positive,
    negative = prep$negative,
    direction = direction
  )
}
