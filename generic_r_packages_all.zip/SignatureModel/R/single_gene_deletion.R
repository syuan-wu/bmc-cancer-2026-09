#' Single-gene deletion sensitivity analysis
#'
#' Fits the complete signature and then refits models after deleting one gene at
#' a time. This is a sensitivity analysis of the selected model; it does not prove
#' that every gene is biologically essential or independently necessary in unseen patients.
#'
#' @param data Development data.frame.
#' @param response Binary response column name.
#' @param genes Final signature genes.
#' @param positive Optional positive-class label.
#' @param evaluation_data Optional held-out/external labeled data.
#' @return data.frame containing the full-model AUC and one row per deleted gene.
#' @export
single_gene_deletion <- function(data,
                                 response,
                                 genes,
                                 positive = NULL,
                                 evaluation_data = NULL) {
  prep <- .prep_binary_data(data, response, positive)
  train <- prep$data
  genes <- unique(as.character(genes))
  missing_cols <- setdiff(genes, names(train))
  if (length(missing_cols)) stop("Missing gene columns: ", paste(missing_cols, collapse = ", "), call. = FALSE)

  # Keep the analyzed sample set fixed across full and deletion models.
  train <- train[stats::complete.cases(train[, c(response, genes), drop = FALSE]), , drop = FALSE]
  if (nrow(train) < 3L) stop("Too few complete development samples remain.", call. = FALSE)

  target <- train
  if (!is.null(evaluation_data)) {
    target <- as.data.frame(evaluation_data, check.names = FALSE)
    missing_eval <- setdiff(c(response, genes), names(target))
    if (length(missing_eval)) stop("Evaluation data are missing: ", paste(missing_eval, collapse = ", "), call. = FALSE)
    bi <- .binary_info(target[[response]], prep$positive)
    target[[response]] <- bi$y
    target <- target[stats::complete.cases(target[, c(response, genes), drop = FALSE]), , drop = FALSE]
  }

  full_fit <- .fit_glm(train, response, genes)
  full_ev <- .eval_fit(full_fit, target, response)
  out <- data.frame(
    deleted_gene = "NONE_FULL_MODEL",
    n_genes = length(genes),
    auc = full_ev$auc,
    delta_auc_vs_full = 0,
    stringsAsFactors = FALSE
  )

  for (g in genes) {
    reduced <- setdiff(genes, g)
    fit <- .fit_glm(train, response, reduced)
    ev <- .eval_fit(fit, target, response)
    out <- rbind(out, data.frame(
      deleted_gene = g,
      n_genes = length(reduced),
      auc = ev$auc,
      delta_auc_vs_full = ev$auc - full_ev$auc,
      stringsAsFactors = FALSE
    ))
  }
  rownames(out) <- NULL
  out
}
