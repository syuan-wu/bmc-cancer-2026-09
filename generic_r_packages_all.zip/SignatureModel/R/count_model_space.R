#' Count the number of non-empty predictor combinations to be evaluated
#'
#' @param p Number of candidate predictors.
#' @param sizes Integer vector of model sizes.
#' @return data.frame with size, combinations, and cumulative combinations.
#' @export
count_model_space <- function(p, sizes = seq_len(p)) {
  p <- as.integer(p)
  if (length(p) != 1L || is.na(p) || p < 1L) stop("`p` must be a positive integer.", call. = FALSE)
  sizes <- sort(unique(as.integer(sizes)))
  if (any(sizes < 1L | sizes > p)) stop("All `sizes` must be between 1 and p.", call. = FALSE)
  n <- vapply(sizes, function(k) choose(p, k), numeric(1))
  data.frame(size = sizes, combinations = n, cumulative = cumsum(n))
}
