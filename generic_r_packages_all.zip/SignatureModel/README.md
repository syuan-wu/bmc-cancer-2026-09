# SignatureModel

`SignatureModel` is a dataset-agnostic R package for constructing a final multigene logistic signature after upstream feature discovery.

It contains no TCGA/KIRC-specific paths, labels, or gene names.

## Main functions

- `stepwise_logistic_select()` — optional stepwise reduction of an upstream candidate set.
- `count_model_space()` — reports the exact exhaustive search space.
- `search_gene_combinations()` — evaluates all requested gene combinations and returns the best model for each size and the global best.
- `fit_gene_signature()` — fits the locked final logistic model.
- `model_specification()` — exports genes, coefficients, intercept, and scoring equations.
- `predict_gene_signature()` / `evaluate_signature()` — applies the frozen coefficients to new data.
- `single_gene_deletion()` — sensitivity analysis after deleting one signature gene at a time.

## Example workflow

```r
library(SignatureModel)

set.seed(7)
n <- 180
p <- 20
d <- as.data.frame(matrix(rnorm(n*p), nrow = n))
names(d) <- paste0("G", seq_len(p))
d$response <- rbinom(n, 1, plogis(0.9*d$G2 - 0.8*d$G5 + 0.6*d$G11))

# Optional stepwise reduction from a larger candidate set
sw <- stepwise_logistic_select(d, "response", paste0("G", 1:20), trace = 0)

# Exact combination count for 20 genes and all non-empty subsets
count_model_space(20, 1:20)
# sum = 2^20 - 1 = 1,048,575

# For demonstration, search a smaller set.
search <- search_gene_combinations(
  d, "response", candidates = paste0("G", 1:8), sizes = 1:8,
  keep = "best_per_size", progress = FALSE
)
search$best_per_size
search$global_best

best_genes <- strsplit(search$global_best$genes, ";", fixed = TRUE)[[1]]
final <- fit_gene_signature(
  d, "response", best_genes,
  preprocessing_note = "Apply the same expression preprocessing used in the development cohort."
)
model_specification(final)
single_gene_deletion(d, "response", best_genes)
```

## Interpretation notes

1. If `evaluation_data = NULL`, exhaustive AUC optimization is performed on the development cohort and is therefore apparent development-set performance.
2. `single_gene_deletion()` is intentionally described as a **sensitivity analysis**, not proof that every gene is essential.
3. The final model should be locked before it is evaluated in independent samples.
4. Exhaustive combination search and deletion sensitivity analysis use a common complete-case sample set across the compared candidate genes so model comparisons are not driven by changing sample counts.
5. New samples must be processed on the same expression scale used to fit the coefficients. The package does not silently harmonize RNA-seq and microarray measurements.
