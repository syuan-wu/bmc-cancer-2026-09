# Generic R packages for the three public source-code modules

This folder contains three independent, dataset-agnostic R packages derived from the computational workflow:

1. **MPICluster** — multi-parameter feature preprocessing, standardization, Euclidean/Ward.D2 hierarchical clustering, and silhouette scanning.
2. **IterGeneSelect** — iterative sampling of unique gene subsets, logistic-regression fitting, AUC calculation, and selection-frequency ranking.
3. **SignatureModel** — optional stepwise candidate reduction, exhaustive gene-combination search, final logistic-signature fitting, frozen prediction, model specification, and single-gene deletion sensitivity analysis.

## Design principles

- No TCGA/GEO file paths, accession numbers, cancer types, sample counts, or fixed gene names are embedded in the packages.
- All data are supplied by the user as ordinary R data frames/matrices.
- The iterative sampler defaults to 10,000 iterations but the number is configurable.
- Within each sampling iteration, genes are drawn **without replacement**; the full pool is restored for the next iteration.
- Development-set AUC is explicitly labeled as such. Random gene-subset sampling is not presented as patient-level validation.
- Exhaustive combination search can optionally be evaluated on a separate held-out/external data frame.
- Single-gene deletion is described as a sensitivity analysis, not proof of biological essentiality.
- Model coefficients and intercept can be exported with an exact scoring equation.

## Before public release

Replace the placeholder package author/email metadata in each `DESCRIPTION` file with the final author and maintainer information. The source package code should also be run through `R CMD check` in an R environment before the GitHub release.
