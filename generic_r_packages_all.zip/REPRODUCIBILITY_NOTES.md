# Reproducibility notes

These packages intentionally separate algorithmic implementation from study-specific input data.

## MPICluster

The public implementation makes each preprocessing decision explicit: optional P-value-to-binary conversion, missing/non-finite handling, feature standardization, distance metric, linkage method, candidate k values, and final k.

## IterGeneSelect

The default workflow samples a fixed number of unique predictors without replacement within each iteration and restores the full pool before the next iteration. A user-specified `seed` enables exact reruns. If no external `evaluation_data` is supplied, AUC is calculated on the development cohort and must not be interpreted as independent validation.

## SignatureModel

The public implementation can reproduce the model-construction logic in a dataset-independent way: optional stepwise reduction, exhaustive combination search over specified model sizes, final logistic-model fitting, coefficient/intercept extraction, and single-gene deletion sensitivity analysis. The package permits a separate `evaluation_data` argument but does not force an internal train/test split.

The package does not automatically normalize or batch-correct external transcriptomic platforms because those operations must match the preprocessing assumptions used to fit a specific model. Users should document the required expression scale through the `preprocessing_note` stored with `fit_gene_signature()`.
